package com.codigoFlecha.Rota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RotaApplication.class, args);
	}

}
